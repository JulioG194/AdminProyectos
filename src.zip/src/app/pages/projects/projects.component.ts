import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

export interface DialogData {
  name: string;
  delegate:string;
  chores:string; //tareas
}


@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})

export class ProjectsComponent implements OnInit {
  
  test:number;

  projects: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers','Alexa','Julio','Yeye','Anto',
                            'Sarita','Santo','Dani','Tere'];
  projects1: string[] = [];

  ngOnInit(){
  }
  name: string;
  delegate:string;
  chores:string; //tareas
  
  constructor(public dialog: MatDialog) {
    this.test=3;
  }

  openNewProject(): void {
    const dialogRef = this.dialog.open(NewProjectModalComponent, {
      width: '700px',
      data: {name: this.name , delegate: this.delegate , chores:this.chores}
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.name = result;
    this.delegate = result;
    this.chores = result;
  });

  }

   openActivities(): void {
    const dialogRef = this.dialog.open(ActivitiesModalComponent, {
      width: '700px',
      data: {name: this.name , delegate: this.delegate , chores:this.chores}
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.name = result;
    this.delegate = result;
    this.chores = result;
  });
  
  }

}

@Component({
  selector: 'newProject-modal',
  templateUrl: './newProject-modal.component.html',
  styleUrls: ['./newProject-modal.component.css']
})

export class NewProjectModalComponent {

  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers','Alexa','Julio','Yeye','Anto',
                            'Sarita','Santo','Dani','Tere'];

  constructor(
    public dialogRef: MatDialogRef<NewProjectModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}


@Component({
  selector: 'activities-modal',
  templateUrl: './activities-modal.component.html',
  styleUrls: ['./activities-modal.component.css']
})

export class ActivitiesModalComponent {

  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers','Alexa','Julio','Yeye','Anto',
                            'Sarita','Santo','Dani','Tere'];

  constructor(
    public dialogRef: MatDialogRef<ActivitiesModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}


