import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit {

  post = true;
  

  people: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers','Alexa','Julio','Yeye','Anto',
                            'Sarita','Santo','Dani','Tere'];

  people1: string[] = []; //para pruebas graficas
  
  constructor() {  }

  ngOnInit() {
  }

}
