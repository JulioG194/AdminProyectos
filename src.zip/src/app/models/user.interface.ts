export interface User {
        name: string;
        email: string;
        password: string;
        id?: string;
        // public img?: string,
        // public role?: string,
        // public google?: boolean

}

